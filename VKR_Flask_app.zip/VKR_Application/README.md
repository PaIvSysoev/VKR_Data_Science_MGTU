# VKR_Application
This is an education project
